The 3 data files contain uniaxial compression data at room temperature.

Jorgen@PolymerFEM.com
